
import java.util.Random;

public class Character {

    int hp;
    int strength;
    int Xposition;
    int Yposition;

    Random random = new Random();

    public Character(int hp, int strength, int Xposition, int Yposition) {
        this.hp = hp;
        this.strength = strength;
        this.Xposition = Xposition;
        this.Yposition = Yposition;
    }

    public void useItem(Item item) {
        //int itemSelec = random.nextInt(4);
        if (item.name.equals("Power")) {
            //item = new Item("Power", 5);
            int currentStrength = strength;
            strength = currentStrength + item.modifier;

        } else if (item.name.equals("Healing")) {
            //item = new Item("Healing", 5);
            int currentHp = hp;
            hp = currentHp + item.modifier;
        } else if (item.name.equals("PoisonPlant")) {
            //item = new Item("PoisonPlant", 5);
            int currentStrength = strength;
            strength = currentStrength - item.modifier;
        } else if (item.name.equals("BearTrap")) {
            //item = new Item("BearTrap", 5);
            int currentHp = hp;
            hp = currentHp - item.modifier;
        } else {

        }
    }

    public void useAbility() {
        int abilitySelec = random.nextInt(2);
        if (abilitySelec == 0) {
            System.out.println("Alien ability");
        } else if (abilitySelec == 1) {
            System.out.println("Depredator ability");
        } else {
        }
    }


    //getters y setters
    public void setHp(int hp) {
        this.hp = hp;
    }

    public int getHp() {
        return hp;
    }

    public void setStrength(int strength) {
        this.strength = strength;
    }

    public int getStrength() {
        return strength;
    }

    public int getPositionX() {
        return Xposition;
    }

    public int getPositionY() {
        return Yposition;
    }

    public void setPositionX(int Xposition) {
        this.Xposition = Xposition;
    }

    public void setPositionY(int Yposition) {
        this.Yposition = Yposition;
    }
}
