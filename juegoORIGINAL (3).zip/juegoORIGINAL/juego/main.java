

import java.util.Scanner;
import java.util.Random;

public class main {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Random numRandom = new Random();
        int planeX = 0;
        int planeY = 0;
        int opcMap;
        int opcCharacter;
        System.out.println("Welcome to the game Alien vs Depredador");
        System.out.println("Select your character");
        System.out.println("1: ALien | 2: Depredador");
        opcCharacter = input.nextInt();

        while (opcCharacter < 1 || opcCharacter > 2) {
            System.out.println("Please select a valid option");
            System.out.println("1: Alien | 2: Depredador");
            opcCharacter = input.nextInt();
        }

        System.out.println("1: Choose map | 2: Random map");
        opcMap = input.nextInt();

        switch (opcMap) {
            case 1:
                System.out.println("Enter the with of the map");
                planeX = input.nextInt();
                System.out.println("Enter the length of the map");
                planeY = input.nextInt();
                break;
            case 2:
                planeX = numRandom.nextInt(100) + 1;
                planeY = numRandom.nextInt(100) + 1;
                System.out.println("width: " + planeX + "\nlength: " + planeY);
                break;
            default:
                System.out.println("Invalid option. Generating random map.");
                planeX = numRandom.nextInt(100) + 1;
                planeY = numRandom.nextInt(100) + 1;
                System.out.println("width: " + planeX + "\nlength: " + planeY);
                break;
        }
       
        Map gameMap = new Map(planeX, planeY);

        // Create characters
        Character characterX = new Alien(100, 30, 0, 0);
        Character characterY = new Depredator(100, 30, planeX - 1, planeY - 1);
        Character jugador;
        Character maquina;
        
        if(opcCharacter==1){//selecciono alien,
            jugador=characterX;//el jugador usa al alien
            maquina=characterY;//la maquina usara al depredador
        }else{//selecciono depredador
            jugador=characterY;//el jugador usa al depredador
            maquina=characterX;//establienco que la maquina usara al alien
        }

        // Place characters on the map
        gameMap.placeCharacters(characterX, characterY);

        // Game loop
        boolean gameRunning = true;
        while (gameRunning) {
            System.out.println("\nAlien");
            System.out.println("Vida: "+ characterX.getHp()+"   Fuerza: "+characterX.getStrength());
            System.out.println("\nDepredador");
            System.out.println("Vida: "+ characterY.getHp()+"   Fuerza: "+characterY.getStrength()+"\n");
            
            gameMap.printMap();
            
            //ver si hay ganador
            if(gameMap.terminarJuego(jugador, maquina)==true) break;//terminar el juego
            
            System.out.println("Seleccione opción:");
            System.out.println("1. Mover | 2. Usar habilidad | q:quit");
            String opcion= input.next();
            
            if(opcion.equals("q")){
                gameRunning = false;
                System.out.println("Thanks for playing!");
            }
            else{
                //jugador
                int newX=0,newY=0;
                if(opcion.equals("1")){//mover
                    System.out.println("Select your move:");
                    System.out.println("1: Up | 2: Down | 3: Left | 4: Right");
                    String userMove = input.next();
                    
                    newX = jugador.getPositionX(); // Obtén la posición actual
                    newY = jugador.getPositionY(); // Obtén la posición actual
                    gameMap.clearPosition(newX, newY);
                    // Actualiza la posición del personaje según la entrada del usuario
                    switch (userMove) {
                        case "1": // Arriba
                            newX = Math.max(0, jugador.getPositionX() - 1);
                            break;
                        case "2": // Abajo
                            newX = Math.min(planeX - 1, jugador.getPositionX() + 1);
                            break;
                        case "3": // Izquierda
                            newY = Math.max(0, jugador.getPositionY() - 1);
                            break;
                        case "4": // Derecha
                            newY = Math.min(planeY - 1, jugador.getPositionY() + 1);
                            break;
                    }
                    
                    if(jugador instanceof Depredator){
                        if(!gameMap.getObject(newX, newY).equals("X# ") && !gameMap.getObject(newX, newY).equals(" # ")){
                            jugador.setPositionX(newX);
                            jugador.setPositionY(newY);
                        }else{
                            System.out.println(gameMap.getObject(newY, newY));
                        }
                    }else{
                        jugador.setPositionX(newX);
                        jugador.setPositionY(newY);
                    }

                    // Actualiza la posición del personaje
                    //jugador.setPositionX(newX);
                    //jugador.setPositionY(newY);
                }else if(opcion.equals("2")){//usar habilidad
                    if(opcCharacter==1) ((Alien)jugador).useAbility(gameMap);
                    else ((Depredator)jugador).useAbility(maquina,gameMap);
                } 
                
                
                
                
                //si el jugador agarró item
                String ObjectInPosition = gameMap.getObject(newX, newY);
                if (ObjectInPosition.equals(" o ")) {
                    int itemSelec = numRandom.nextInt(4);
                    String itemName = "";
                    String efecto = "";
                    switch (itemSelec) {
                        case 0:
                            itemName = "Power";
                            efecto = "Aumentó su ataque en 5";
                            break;
                        case 1:
                            itemName = "Healing";
                            efecto = "Aumentó su vida en 5";
                            break;
                        case 2:
                            itemName = "PoisonPlant";
                            efecto = "Disminuyó su ataque en 5";
                            break;
                        case 3:
                            itemName = "BearTrap";
                            efecto = "Disminuyó su vida en 5";
                            break;
                    }

                    System.out.println("\nEl " + (opcCharacter == 1 ? "Alien" : "Depredador") + " encontró el item: " + itemName + ", efecto: " + efecto);
                    // Crea un objeto Item con el nombre y el modificador correspondientes
                    Item item = new Item(itemName, 5);

                    // Aplica los efectos del objeto al personaje
                    jugador.useItem(item);

                    // Actualiza el mapa para representar la casilla como vacía
                    //gameMap.setObject(newX, newY, " ");
                }
                

                //maquina
                // Mueve al personaje Y de manera aleatoria
                int op= numRandom.nextInt(2);
                
                if(op==0){//mover
                    int newY_X = maquina.getPositionX();
                    int newY_Y = maquina.getPositionY();

                    gameMap.clearPosition(newY_X, newY_Y);

                    int direction = numRandom.nextInt(4);

                    switch (direction) {
                        case 0:
                            newY_X = Math.max(0, maquina.getPositionX() - 1);
                            break;
                        case 1:
                            newY_X = Math.min(planeX - 1, maquina.getPositionX() + 1);
                            break;
                        case 2:
                            newY_Y = Math.max(0, maquina.getPositionY() - 1);
                            break;
                        case 3:
                            newY_Y = Math.min(planeY - 1, maquina.getPositionY() + 1);
                            break;
                    }
                    
                    if(maquina instanceof Depredator){
                        if(!gameMap.getObject(newY_X, newY_Y).equals("X# ") && !gameMap.getObject(newY_X, newY_Y).equals(" # ")){
                            maquina.setPositionX(newY_X);
                            maquina.setPositionY(newY_Y);
                        }
                    }else{
                        maquina.setPositionX(newY_X);
                        maquina.setPositionY(newY_Y);
                    }
                    
                    //String ObjectInPosition = gameMap.getObject(newX, newY);
                    String Object2InPosition= gameMap.getObject(newY_X, newY_Y);

                    if (Object2InPosition.equals(" o ")) {
                        int itemSelec = numRandom.nextInt(4);
                        String itemName = "";
                        String efecto = "";
                        switch (itemSelec) {
                            case 0:
                                itemName = "Power";
                                efecto = "Aumentó su ataque en 5";
                                break;
                            case 1:
                                itemName = "Healing";
                                efecto = "Aumentó su vida en 5";
                                break;
                            case 2:
                                itemName = "PoisonPlant";
                                efecto = "Disminuyó su ataque en 5";
                                break;
                            case 3:
                                itemName = "BearTrap";
                                efecto = "Disminuyó su vida en 5";
                                break;
                        }
                        System.out.println("El " + (opcCharacter == 1 ? "Depredador" : "Alien") + " encontró el item: " + itemName + ", efecto: " + efecto);
                        // Crea un objeto Item con el nombre y el modificador correspondientes
                        Item item = new Item(itemName, 5);

                        // Aplica los efectos del objeto al personaje
                        maquina.useItem(item);

                        // Actualiza el mapa para representar la casilla como vacía
                        //gameMap.setObject(newX, newY, " ");
                    }
                }else{//usar habilidad
                    if(opcCharacter==1) ((Depredator)maquina).useAbility(jugador,gameMap);
                    else ((Alien)maquina).useAbility(gameMap);
                }
                
                if(opcCharacter==1){
                    gameMap.placeCharacters(jugador, maquina);
                    //comprobar si sucede una batalla
                    gameMap.combate(jugador, maquina);
                }
                else {
                    gameMap.placeCharacters(maquina, jugador);
                    //comprobar si sucede una batalla
                    gameMap.combate(maquina, jugador);
                }
                
                
            }
        }
    }
}
