
public class Item {
    protected String name;
    protected int modifier;

    public Item(String name, int modifier) {
        this.name = name;
        this.modifier = modifier;
    }
}
