public class BearTrap extends Item{
    public BearTrap(String name, int modifier){
        super(name,modifier);
    }
    public String getName(){
        return name;
    }
}