


public class Depredator extends Character {

    public Depredator(int hp, int strength, int Xposition, int Yposition) {
        super(hp, strength, Xposition, Yposition);
    }
    
    public void useAbility(Character alien,Map mapa){
        int yAlien= alien.getPositionY();
        int yDepredador= this.getPositionY();
        
        if(this.getPositionX()==alien.getPositionX()){
            boolean bloqueo=false;
            int menor,mayor;
            if(yAlien>yDepredador){
                menor=yDepredador;
                mayor=yAlien;
            }else{
                menor=yAlien;
                mayor=yDepredador;
            }
            
            for (int i = menor; i <= mayor; i++) {
                if (mapa.getMap()[this.getPositionX()][i].equals("X# ") || mapa.getMap()[this.getPositionX()][i].equals(" # ")) {
                    bloqueo = true;
                    break;
                }
            }

            if (bloqueo) {
                System.out.println("Depredador usa habilidad, bloqueo evita impacto");
            } else {
                if(this.getStrength()>alien.getStrength()){
                    alien.hp-= this.getStrength()-alien.getStrength();
                    System.out.println("Depredador usa habilidad, le resta "+(this.getStrength()-alien.getStrength())+" de vida a Alien");
                }else{
                    System.out.println("Depredador usa habilidad, no tiene sufiente fuerza para dañar a Alien");
                }
            }
            
        }else{
            System.out.println("Depredador usa habilidad, no afecta a nadie");
        }
    }
}