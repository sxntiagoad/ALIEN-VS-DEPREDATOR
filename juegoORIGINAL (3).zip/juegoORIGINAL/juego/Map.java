

import java.util.Random;

public class Map {

    private int row;
    private int col;
    private String[][] map;
    private Random random = new Random();
    private Character characterX;
    private Character characterY;
    
    public Map(int row, int col) {
        this.row = row;
        this.col = col;
        this.map = new String[row][col];
        initializeMap();
        setItem();
    }

    public int getRow() {
        return row;
    }

    public void setRow(int row) {
        this.row = row;
    }

    public int getCol() {
        return col;
    }

    public void setCol(int col) {
        this.col = col;
    }
    
    private void initializeMap() {
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < col; j++) {
                map[i][j] = "   ";
            }
        }
    }

    public void printMap() {
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < col; j++) {
                System.out.print("[" + map[i][j] + "]");
            }
            System.out.println();
        }
    }

    public void setItem() {
        int numItems = (row * col) / 2;
        for (int i = 0; i < numItems; i++) {
            int x = random.nextInt(row);
            int y = random.nextInt(col);
            map[x][y] = " o ";
        }
    }

    public void placeCharacters(Character characterX, Character characterY) {
        if(map[characterX.getPositionX()][characterX.getPositionY()].equals(" # ")){
            map[characterX.getPositionX()][characterX.getPositionY()] = "X# ";
        }
        else if(!map[characterX.getPositionX()][characterX.getPositionY()].equals("X# ")){
            map[characterX.getPositionX()][characterX.getPositionY()] = " X ";
        }
        
        map[characterY.getPositionX()][characterY.getPositionY()] = " Y ";
    }

    public boolean isValidPosition(int row, int col) {
        return row >= 0 && row < map.length && col >= 0 && col < map[0].length;
    }

    public void clearPosition(int x, int y) {
        if (isValidPosition(x, y)) {
            if(this.map[x][y].equals("X# ")){
                this.map[x][y] = " # ";
            }else{
                this.map[x][y] = "   ";
            }
        }
    }

    public String getObject(int row, int col) {
        return map[row][col];
    }

    public void setObject(int x, int y, String object) {
        if (isValidPosition(x, y)) {
            // Verifica si la posición (x, y) está dentro de los límites del mapa
            map[x][y] = object;
        } else {
            System.out.println("Invalid position: (" + x + ", " + y + ")");
        }
    }

    public String[][] getMap() {
        return map;
    }
    
    public void combate(Character alien, Character depredator){
        int xAlien= alien.getPositionX();
        int yAlien= alien.getPositionY();
        int xDepredator= depredator.getPositionX();
        int yDepredator= depredator.getPositionY();
        
        if(xAlien==xDepredator && yAlien==yDepredator){//se lleva a cabo un combate
            this.map[xAlien][yAlien] = "X Y";
            int fuerzaAlien= alien.getStrength();
            int fuerzaDepredator= depredator.getStrength();
            if(fuerzaAlien>fuerzaDepredator){//alien tiene mayor fuerza
                depredator.setHp(depredator.getHp()-(fuerzaAlien-fuerzaDepredator));
                System.out.println("Alien ataca a Depredator, le resta "+(fuerzaAlien-fuerzaDepredator)+" de vida a Depredator");
            }else if(fuerzaDepredator>fuerzaAlien){//depredator tiene mayor fuerza
                alien.setHp(alien.getHp()-(fuerzaDepredator-fuerzaAlien));
                System.out.println("Depredator ataca a Alien, le resta "+(fuerzaDepredator-fuerzaAlien)+" de vida a Alien");
            }else{//ambos tienen la misma cantidad de fuerza, no sucede nada
               
            }
        }
    }
    
    public boolean terminarJuego(Character alien, Character depredator){
        if(alien.getHp()<=0 || depredator.getHp()<=0){
            if(alien.getHp()<=0){
                System.out.println("El depredador ganó el juego");
            }else{
                System.out.println("El alien ganó el juego");
            }
            return true;
        }
        return false;
    }
}
