


public class PoisonPlant extends Item{
    public PoisonPlant(String name, int modifier){
        super(name,modifier);
    }
    public String getName(){
        return name;
    }
}
