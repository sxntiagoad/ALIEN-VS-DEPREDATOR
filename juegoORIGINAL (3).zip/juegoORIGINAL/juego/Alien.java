

public class Alien extends Character {

    public Alien(int hp, int strength, int Xposition, int Yposition) {
        super(hp, strength, Xposition, Yposition);
        
    }

    public void useAbility(Map mapa) {
        if(mapa.getMap()[this.getPositionX()][this.getPositionY()].equals("X Y")){
            System.out.println("Alien no puede usar habilidad, el depredator se encuentra en el mismo lugar");
        }else{
            mapa.getMap()[this.getPositionX()][this.getPositionY()]="X# ";
            System.out.println("Alien deja una trampa");
        }
        
    }
}
