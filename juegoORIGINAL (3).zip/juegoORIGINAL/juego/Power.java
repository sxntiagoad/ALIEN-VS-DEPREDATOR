

public class Power extends Item {

    public Power(String name, int modifier) {
        super(name, modifier);
    }

    public String getName() {
        return name;
    }
}
