


public class Healing extends Item{
    public Healing(String name, int modifier){
        super(name,modifier);
    }
    public String getName(){
        return name;
    }
}